import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
COMPILER=ROOT/'src'/'novax.py'

class CompilerTests(unittest.TestCase):
    def compile_source(self, source, emit=True):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'test.nx';path.write_text(source)
            cmd=[sys.executable,str(COMPILER),str(path),'-o',str(Path(d)/('test.ll' if emit else 'test'))]
            if emit:cmd.append('--emit-llvm')
            p=subprocess.run(cmd,capture_output=True,text=True)
            out=Path(d)/('test.ll' if emit else 'test')
            ir=out.read_text() if out.exists() and emit else ''
            exe=subprocess.run([str(out)],capture_output=True,text=True) if p.returncode==0 and not emit else None
            return p,ir,exe
    def test_constant_folding(self):
        p,ir,_=self.compile_source('fn main() -> int { let x = 6*7; print(x); return 0; }')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('i32 42',ir)
    def test_immutable(self):
        p,_,_=self.compile_source('fn main() -> int { let x = 5; x = 9; return x; }')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('immutable',p.stderr)
    def test_native(self):
        p,_,exe=self.compile_source('fn main() -> int { print(6*7); return 0; }',False)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(exe.stdout,'42\n')
    def test_wrong_arity(self):
        p,_,_=self.compile_source('fn sum(a: int) -> int {return a;} fn main() -> int {return sum();}')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('Wrong number',p.stderr)

if __name__=='__main__':unittest.main()

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
COMPILER=ROOT/'src'/'novax.py'

class CompilerTests(unittest.TestCase):
    def compile_source(self, source, emit=True, optimization="2"):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'test.nx';path.write_text(source)
            cmd=[sys.executable,str(COMPILER),str(path),'-o',str(Path(d)/('test.ll' if emit else 'test'))]
            cmd.append("-O"+optimization)
            if emit:cmd.append('--emit-llvm')
            p=subprocess.run(cmd,capture_output=True,text=True)
            out=Path(d)/('test.ll' if emit else 'test')
            ir=out.read_text() if out.exists() and emit else ''
            exe=subprocess.run([str(out)],capture_output=True,text=True) if p.returncode==0 and not emit else None
            return p,ir,exe
    def test_constant_folding(self):
        p,ir,_=self.compile_source('fn main() -> int { let x = 6*7; print(x); return 0; }')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('i32 42',ir)
    def test_immutable(self):
        p,_,_=self.compile_source('fn main() -> int { let x = 5; x = 9; return x; }')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('immutable',p.stderr)
    def test_native(self):
        p,_,exe=self.compile_source('fn main() -> int { print(6*7); return 0; }',False)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(exe.stdout,'42\n')
    def test_wrong_arity(self):
        p,_,_=self.compile_source('fn sum(a: int) -> int {return a;} fn main() -> int {return sum();}')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('Wrong number',p.stderr)

class LanguageV02Tests(CompilerTests):
    def native(self, source, expected):
        for level in ('0','3'):
            with self.subTest(optimization=level):
                p,_,exe=self.compile_source(source,False,level)
                self.assertEqual(p.returncode,0,p.stderr)
                self.assertEqual(exe.returncode,0,exe.stderr)
                self.assertEqual(exe.stdout,expected)

    def test_short_circuit_side_effects(self):
        self.native('fn noisy() -> int { print(99); return 1; }\nfn main() -> int {\nprint(false && noisy()); print(true || noisy());\nprint(true && noisy()); print(false || noisy());\nprint((false || true) && (true || noisy())); return 0;\n}', '0\n1\n99\n1\n99\n1\n1\n')

    def test_nested_loops_and_else_if(self):
        self.native('fn main() -> int {\nvar i = 0; var total = 0;\nwhile i < 6 {\ni = i + 1;\nif i == 2 { continue; } else if i == 5 { break; }\nvar j = 0;\nwhile true { j = j + 1; if j == 2 { break; } total = total + i; }\n}\nprint(total); print(i); return 0;\n}', '8\n5\n')

    def test_calls_comments_and_minimum_integer(self):
        self.native('/* Multi-line\ncomment */\nfn hello() -> int { print(42); return 0; }\nfn main() -> int { hello(); print(-2147483648); return 0; }', '42\n-2147483648\n')

    def test_invalid_control_flow(self):
        for keyword in ('break','continue'):
            with self.subTest(keyword=keyword):
                p,_,_=self.compile_source('fn main() -> int { '+keyword+'; return 0; }')
                self.assertNotEqual(p.returncode,0)
                self.assertIn('only allowed inside a loop',p.stderr)

    def test_unterminated_comment(self):
        p,_,_=self.compile_source('fn main() -> int { return 0; } /* unfinished')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('Unterminated block comment',p.stderr)

    def test_reserved_runtime_function(self):
        p,_,_=self.compile_source('fn printf() -> int {return 0;} fn main() -> int {return 0;}')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('Reserved name',p.stderr)

    def test_integer_range(self):
        for literal in ('2147483648','-2147483649'):
            p,_,_=self.compile_source('fn main() -> int { print('+literal+'); return 0; }')
            self.assertNotEqual(p.returncode,0)
            self.assertIn('i32 range',p.stderr)

class StringTests(unittest.TestCase):
    compile_source=CompilerTests.compile_source
    native=LanguageV02Tests.native

    def test_string_functions_and_variables(self):
        self.native('fn choose(n: int, text: str) -> str {\nif n { return text; } else { return "fallback"; }\n}\nfn main() -> int {\nlet message: str = "Hallo NOVA-X";\nvar selected = choose(1, message);\nprint(selected); selected = choose(0, message); print(selected);\nprint(42); return 0;\n}', 'Hallo NOVA-X\nfallback\n42\n')

    def test_unicode_escapes_and_format_safety(self):
        self.native('fn main() -> int {\nprint("Grüße 🌍"); print("Zeile 1\\nZeile 2\\t\\"ok\\"");\nprint("100% %s %n"); print(""); print("/* not a comment");\nprint("// not a comment"); print("\\u0041"); return 0;\n}', 'Grüße 🌍\nZeile 1\nZeile 2\t"ok"\n100% %s %n\n\n/* not a comment\n// not a comment\nA\n')

    def test_type_errors(self):
        cases = [
            ('let x: int = "text";', 'Declaration'),
            ('let x: str = 1;', 'Declaration'),
            ('var x = "text"; x = 2;', 'Assignment'),
            ('print("x" + 1);', 'Operator'),
            ('print(1 + "x");', 'Operator'),
            ('print(!"x");', 'Unary'),
            ('if "x" { print(1); }', 'if condition'),
            ('while "x" { break; }', 'while condition'),
            ('print(false && "x");', 'Operator'),
        ]
        for body, diagnostic in cases:
            with self.subTest(body=body):
                p,_,_=self.compile_source('fn main() -> int {'+body+' return 0;}')
                self.assertNotEqual(p.returncode,0)
                self.assertIn(diagnostic,p.stderr)
                self.assertNotIn('Traceback',p.stderr)

    def test_function_type_errors(self):
        for source,diagnostic in [
            ('fn f(x: str) -> int {return 0;} fn main() -> int {return f(1);}', 'Argument'),
            ('fn f() -> str {return 1;} fn main() -> int {return 0;}', 'Return'),
            ('fn main() -> str {return "text";}', 'main must return int'),
        ]:
            p,_,_=self.compile_source(source)
            self.assertNotEqual(p.returncode,0)
            self.assertIn(diagnostic,p.stderr)

    def test_invalid_string_literals(self):
        for literal in ['"unterminated', r'"bad\q"', r'"nul\u0000"', r'"\ud800"']:
            with self.subTest(literal=literal):
                p,_,_=self.compile_source('fn main() -> int {print('+literal+');return 0;}')
                self.assertNotEqual(p.returncode,0)
                self.assertNotIn('Traceback',p.stderr)

if __name__=='__main__':unittest.main()


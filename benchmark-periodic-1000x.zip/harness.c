#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
extern int32_t nx_user_checksum_slow(int32_t);
extern int32_t nx_user_checksum_fast(int32_t);
static volatile int32_t sink;
static double now(void) {
    struct timespec time;
    if (clock_gettime(CLOCK_MONOTONIC, &time)) exit(2);
    return (double)time.tv_sec + (double)time.tv_nsec * 1e-9;
}
static void check(int32_t n) {
    int32_t a=nx_user_checksum_slow(n), b=nx_user_checksum_fast(n);
    if (a!=b) { fprintf(stderr,"Mismatch for %d: %d != %d\n",n,a,b); exit(1); }
}
static double measure(int fast) {
    int count=fast ? 17000000 : 17;
    double start=now();
    for (int i=0;i<count;++i) {
        int32_t n=20000000-(i%17);
        sink=fast ? nx_user_checksum_fast(n) : nx_user_checksum_slow(n);
    }
    return (now()-start)/count;
}
int main(void) {
    for (int32_t i=0;i<4096;++i) check(i);
    uint32_t seed=1000;
    for (int i=0;i<64;++i) {seed=1664525u*seed+1013904223u;check((int32_t)(seed%20000001u));}
    int32_t boundaries[]={-2147483647-1,-1,20000000,20000001,2147483647};
    for (unsigned i=0;i<sizeof(boundaries)/sizeof(boundaries[0]);++i)check(boundaries[i]);
    if (nx_user_checksum_fast(20000000)!=999433) return 1;
    measure(1);measure(0);
    puts("sample,slow_seconds_per_call,fast_seconds_per_call");
    for (int sample=0;sample<9;++sample) {
        double slow,fast;
        if(sample%2){fast=measure(1);slow=measure(0);}else{slow=measure(0);fast=measure(1);}
        printf("%d,%.12f,%.12f\n",sample,slow,fast);
    }
    fprintf(stderr,"Correctness: 4165 inputs matched; checksum=999433; sink=%d\n",sink);
    return 0;
}

import argparse,json,random,statistics,subprocess,sys,time
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--compiler',required=True);args=parser.parse_args()
root=Path(__file__).resolve().parent
source=(root/'periodic_checksum.nx').read_text()
(root/'periodic_slow.nx').write_text(source.replace('print(checksum_fast(20000000))','print(checksum_slow(20000000))'))
for name,filename in [('fast','periodic_checksum.nx'),('slow','periodic_slow.nx')]:
 subprocess.run([sys.executable,str(Path(args.compiler).resolve()),str(root/filename),'-O3','-o',str(root/('program-'+name))],check=True,capture_output=True)
samples={'slow':[],'fast':[]};rng=random.Random(1000)
for name in samples:subprocess.run([str(root/('program-'+name))],check=True,capture_output=True)
for _ in range(11):
 order=list(samples);rng.shuffle(order)
 for name in order:
  start=time.perf_counter();p=subprocess.run([str(root/('program-'+name))],check=True,capture_output=True,text=True);elapsed=time.perf_counter()-start
  assert p.stdout.strip()=='999433'
  samples[name].append(elapsed)
report={name:{'median_seconds':statistics.median(times),'samples_seconds':times} for name,times in samples.items()}
report['speedup']=report['slow']['median_seconds']/report['fast']['median_seconds']
(root/'process_results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

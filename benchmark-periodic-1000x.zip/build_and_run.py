import argparse,json,platform,statistics,subprocess,sys
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--compiler',required=True,help='Path to NOVA-X 0.8 src/novax.py')
args=parser.parse_args()
root=Path(__file__).resolve().parent
src=Path(args.compiler).resolve().parent
sys.path.insert(0,str(src))
from frontend import analyze_source,optimize_program
from ranges import RangeAnalysis
from backend import Compiler
from llvmlite import binding
program,_=optimize_program(analyze_source((root/'periodic_checksum.nx').read_text(),str(root/'periodic_checksum.nx')))
compiler=Compiler(program,RangeAnalysis().analyze(program))
# Test-only harness entry: source language does not expose FFI or libraries.
compiler.module.get_global('main').name='nx_benchmark_unused_main'
llvm=str(compiler.module);binding.parse_assembly(llvm).verify()
(root/'kernels.ll').write_text(llvm)
subprocess.run(['clang','-O3','-c',str(root/'kernels.ll'),'-o',str(root/'kernels.o')],check=True,capture_output=True)
subprocess.run(['clang','-O3',str(root/'harness.c'),str(root/'kernels.o'),str(src/'runtime.c'),'-o',str(root/'benchmark')],check=True,capture_output=True)
p=subprocess.run([str(root/'benchmark')],check=True,capture_output=True,text=True,timeout=90)
rows=[[float(x) for x in row.split(',')[1:]] for row in p.stdout.splitlines()[1:]]
slow=statistics.median(row[0] for row in rows);fast=statistics.median(row[1] for row in rows)
report={'cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),
        'os':platform.platform(),'python':sys.version.split()[0],'clang':subprocess.check_output(['clang','--version'],text=True).splitlines()[0],
        'checks':p.stderr.strip(),'input_range':[0,20000000],'timed_inputs':'20,000,000 minus i%17',
        'slow_repetitions':17,'fast_repetitions':17000000,'samples':9,'rows_seconds_per_call':rows,
        'slow_median_seconds':slow,'fast_median_seconds':fast,'speedup':slow/fast,'modulo_reductions':compiler.modulo_reductions}
(root/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

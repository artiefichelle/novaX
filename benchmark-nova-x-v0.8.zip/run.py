"""Reproducible interleaved comparison; invoke with a dependency-ready Python."""
import argparse,json,platform,random,statistics,subprocess,sys,time
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--baseline',required=True,help='Path to NOVA-X 0.7 src/novax.py')
parser.add_argument('--candidate',required=True,help='Path to NOVA-X 0.8 src/novax.py')
args=parser.parse_args()
root=Path(__file__).resolve().parent

def command(cmd):
    start=time.perf_counter()
    p=subprocess.run([str(x) for x in cmd],capture_output=True,text=True,timeout=90)
    if p.returncode:raise RuntimeError(p.stderr)
    return time.perf_counter()-start,p.stdout

builds={
    'NOVA-X 0.7 -O3':(Path(args.baseline).resolve(),[]),
    'NOVA-X 0.8 disabled -O3':(Path(args.candidate).resolve(),['--no-range-opt']),
    'NOVA-X 0.8 -O3':(Path(args.candidate).resolve(),[]),
}
executables={};compile_times={}
for i,(name,(compiler,extra)) in enumerate(builds.items()):
    exe=root/('nova-'+str(i))
    elapsed,_=command([sys.executable,compiler,root/'checksum.nx','-O3','-o',exe]+extra)
    executables[name]=exe;compile_times[name]=elapsed
for name,source in [('C reference -O3','checksum.c'),('C manually reduced -O3','checksum-tuned.c')]:
    exe=root/('c-tuned' if 'manually' in name else 'c-reference')
    elapsed,_=command(['clang','-O3',root/source,'-o',exe])
    executables[name]=exe;compile_times[name]=elapsed
for exe in executables.values():
    _,output=command([exe]);assert output.strip()=='999433'
samples={name:[] for name in executables};rng=random.Random(8025)
for _ in range(11):
    order=list(executables);rng.shuffle(order)
    for name in order:
        elapsed,output=command([executables[name]])
        assert output.strip()=='999433'
        samples[name].append(elapsed)
_,cpu=command(['sysctl','-n','machdep.cpu.brand_string'])
_,clang=command(['clang','--version'])
report={'cpu':cpu.strip(),'os':platform.platform(),'python':sys.version.split()[0],
        'clang':clang.splitlines()[0],'iterations':20000000,'samples_per_variant':11,
        'seed':8025,'checksum':999433,
        'results':{name:{'median_ms':statistics.median(s)*1000,'min_ms':min(s)*1000,
                         'max_ms':max(s)*1000,'samples_seconds':s,
                         'compile_seconds_single_run':compile_times[name]} for name,s in samples.items()}}
(root/'results.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))

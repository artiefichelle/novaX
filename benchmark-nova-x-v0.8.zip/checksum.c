#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
static int32_t add(int32_t a, int32_t b) {
    int32_t result;
    if (__builtin_add_overflow(a, b, &result)) exit(1);
    return result;
}
int main(void) {
    const int32_t data[] = {1, 3, 5, 7, 11, 13, 17, 19};
    int32_t i = 0, sum = 0;
    while (i < 20000000) {
        int32_t index = i % 8;
        if (index < 0 || index >= 8) exit(1);
        sum = add(sum, data[index]) % 1000003;
        i = add(i, 1);
    }
    printf("%d\n", sum);
    return 0;
}

import argparse, json, platform, statistics, subprocess, sys, time
from pathlib import Path
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Reproduce the NOVA-X 0.7 checked-array checksum benchmark')
parser.add_argument('--compiler',required=True,help='Path to NOVA-X src/novax.py')
args=parser.parse_args()
compiler=Path(args.compiler).resolve()

def command(cmd):
    start=time.perf_counter()
    result=subprocess.run([str(c) for c in cmd],capture_output=True,text=True,timeout=90)
    elapsed=time.perf_counter()-start
    if result.returncode: raise RuntimeError(result.stderr)
    return elapsed,result.stdout

variants={}
for level in ['0','3']:
    exe=root/('nova-O'+level)
    compile_time,_=command([sys.executable,compiler,root/'checksum.nx','-O'+level,'-o',exe])
    variants['NOVA-X -O'+level]=(exe,compile_time)
for level in ['0','3']:
    exe=root/('c-O'+level)
    compile_time,_=command(['clang','-O'+level,root/'checksum.c','-o',exe])
    variants['C -O'+level]=(exe,compile_time)
results={}
for name,(exe,compile_time) in variants.items():
    command([exe]) # Warm up once; exclude from measured samples.
    samples=[]
    for _ in range(7):
        elapsed,output=command([exe])
        assert output.strip()=='999433',output
        samples.append(elapsed)
    results[name]={'median_seconds':statistics.median(samples),'min_seconds':min(samples),'max_seconds':max(samples),'samples_seconds':samples,'compile_seconds_one_run':compile_time,'checksum':output.strip()}
_,cpu=command(['sysctl','-n','machdep.cpu.brand_string'])
_,clang=command(['clang','--version'])
report={'cpu':cpu.strip(),'os':platform.platform(),'python':sys.version.split()[0],'clang':clang.splitlines()[0],'iterations':20000000,'samples':7,'results':results}
(root/'results.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
